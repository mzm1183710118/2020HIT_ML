import math

import numpy as np
import pandas as pd


def Data(N, naive=True, posRate=0.4):
    """
    生成数据
    :param N: 数据点总数
    :param naive: 是否满足朴素贝叶斯
    :param posRate:正例所占比例
    :return: 六元组：训练集x和label；验证集x和label；测试集x和label
    """
    posNumber = np.ceil(N * posRate).astype(np.int32)
    sigma = [0.3, 0.4]  # cov11与cov22
    cov12 = 0.3
    pos_mean = [1, 1.2]  # 正例的两维度均值
    neg_mean = [-1, -1.2]  # 反例的两维度均值
    x = np.zeros((N, 2))  # x数组
    y = np.zeros(N).astype(np.int32)  # label数组
    if naive:  # 满足朴素贝叶斯假设
        x[:posNumber, :] = np.random.multivariate_normal(pos_mean, [[sigma[0], 0], [0, sigma[1]]],
                                                         size=posNumber)
        x[posNumber:, :] = np.random.multivariate_normal(neg_mean, [[sigma[0], 0], [0, sigma[1]]],
                                                         size=N - posNumber)

        y[:posNumber] = 1
        y[posNumber:] = 0
    else:  # 不满足朴素贝叶斯假设
        x[:posNumber, :] = np.random.multivariate_normal(pos_mean, [[sigma[0], cov12], [cov12, sigma[1]]],
                                                         size=posNumber)
        x[posNumber:, :] = np.random.multivariate_normal(neg_mean, [[sigma[0], cov12], [cov12, sigma[1]]],
                                                         size=N - posNumber) 
        y[:posNumber] = 1
        y[posNumber:] = 0

    # 下面开始划分训练集、验证集、测试集
    trainRate, verifyRate, testRate = 0.6, 0.2, 0.2
    posTrainNumber, posVerifyNumber = int(math.ceil(posNumber * trainRate)), int(math.ceil(posNumber * verifyRate))
    negTrainNumber, negVerifyNumber = int(math.ceil((N - posNumber) * trainRate)), int(
        math.ceil((N - posNumber) * verifyRate))

    x_Bool = np.zeros(N).astype(np.int32)  # x对应的bool数组，用于切片
    x_Bool[:posTrainNumber] = 1
    x_Bool[posNumber:(posNumber + negTrainNumber)] = 1
    # 划分出训练集
    Train_x, Train_y = x[x_Bool == 1], y[x_Bool == 1]
    # bool数组复原
    x_Bool[:posTrainNumber] = 0
    x_Bool[posNumber:(posNumber + negTrainNumber)] = 0

    # 开始划分验证集
    x_Bool[posTrainNumber:(posTrainNumber + posVerifyNumber)] = 1
    x_Bool[(posNumber + negTrainNumber):(posNumber + negTrainNumber + negVerifyNumber)] = 1
    Verify_x, Verify_y = x[x_Bool == 1], y[x_Bool == 1]

    # bool数组复原
    x_Bool[posTrainNumber:(posTrainNumber + posVerifyNumber)] = 0
    x_Bool[(posNumber + negTrainNumber):(posNumber + negTrainNumber + negVerifyNumber)] = 0
    # 开始划分测试集
    x_Bool[(posTrainNumber + posVerifyNumber):posNumber] = 1
    x_Bool[(posNumber + negTrainNumber + negVerifyNumber):] = 1
    Test_x, Test_y = x[x_Bool == 1], y[x_Bool == 1]

    return Train_x, Train_y, Verify_x, Verify_y, Test_x, Test_y


def XMatrix(x):
    # 获得TrainSet的维度
    num = x.shape
    x_matrix = np.column_stack((np.ones(num[0]).reshape(num[0], 1), x))
    return x_matrix


def loss(x_matrix, y, w, hyper=0):
    N = len(y)
    result = hyper * (w @ w) / 2
    for i in range(N):
        result += -y[i] * w @ x_matrix[i] + np.log(1.0 + np.exp(w @ x_matrix[i]))
    # 将loss归一化
    return result / N


def Accuracy(x_matrix, y, w):
    N = len(y)
    error = 0
    # 依次验证每一个样本是否分类正确
    for i in range(N):
        if (w @ x_matrix[i] > 0 and y[i] == 0) or (w @ x_matrix[i] < 0 and y[i] == 1):
            error += 1
    return 1 - error / N


def SplitData(x, y, trainRate=0.7):
    N = len(y)
    posNumber = 0
    # 先求出正例的数目
    for label in y:
        if label == 1:
            posNumber += 1

    posTrainNumber = int(math.ceil(posNumber * trainRate))
    negTrainNumber = int(math.ceil((N - posNumber) * trainRate))

    x_Bool = np.zeros(N).astype(np.int32)  # x对应的bool数组，用于切片
    x_Bool[:posTrainNumber] = 1
    x_Bool[posNumber:(posNumber + negTrainNumber)] = 1
    # 划分出训练集
    Train_x, Train_y = x[x_Bool == 1], y[x_Bool == 1]
    # bool数组复原
    x_Bool[:posTrainNumber] = 0
    x_Bool[posNumber:(posNumber + negTrainNumber)] = 0

    # 开始划分测试集
    x_Bool[posTrainNumber:posNumber] = 1
    x_Bool[(posNumber + negTrainNumber):] = 1
    Test_x, Test_y = x[x_Bool == 1], y[x_Bool == 1]
    return Train_x, Train_y, Test_x, Test_y


def ReadUCI(path):
    data_set = pd.read_csv(path)  # linux 相对路径
    x = data_set.drop('label', axis=1)
    y = data_set['label']
    dataX, dataY = np.array(x, dtype=float), np.array(y)
    N = len(dataY)
    posNumber = 0
    for i in range(N):
        if dataY[i] == 1:
            posNumber += 1
    # 因为数据量太大，故缩减读取的数据量
    useRate = 1
    posUseNumber = int(math.ceil(posNumber * useRate))
    negUseNumber = int(math.ceil((N-posNumber) * useRate))

    x_Bool = np.zeros(N).astype(np.int32)  # x对应的bool数组，用于切片
    x_Bool[:posUseNumber] = 1
    x_Bool[posNumber:(posNumber + negUseNumber)] = 1
    # 划分出训练集
    dataX, dataY = dataX[x_Bool == 1], dataY[x_Bool == 1]

    Train_x, Train_y, Test_x, Test_y = SplitData(dataX, dataY)
    return Train_x, Train_y, Test_x, Test_y
