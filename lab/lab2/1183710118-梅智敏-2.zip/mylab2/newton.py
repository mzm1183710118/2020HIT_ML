import numpy as np

import basicOperation as Bo


class MyNewton(object):
    def __init__(self, x, y, w_0, hyper=0, delta=1e-6):
        """
        构建一个牛顿法对象
        :param x: 数据集矩阵
        :param y: label集
        :param w_0: 初始w
        :param hyper: 正则项的超参数
        :param delta: 求解精度
        """
        self.x = x
        self.y = y
        self.w_0 = w_0
        self.hyper = hyper
        self.delta = delta
        self.__m = len(x)
        self.__n = len(x[0])

    def __sigmoid(self, z):
        return 1.0 / (1.0 + np.exp(z))

    def __derivative(self, w):
        """
        求出导函数
        :param w: 当前的w
        :return: 返回当前的导数
        """
        result = np.zeros(self.__n)
        # 依次取出X和Y的所有行
        for i in range(self.__m):
            result += (self.x[i] * (self.y[i] -
                                    (1.0 - self.__sigmoid(w @ self.x[i]))))
        return -1 * result + self.hyper * w

    def __second_derivative(self, w):
        """
        求出hessian matrix的逆矩阵
        :param w:
        :return:
        """
        ans = np.eye(self.__n) * self.hyper
        # 依次取出X和Y的所有行
        for i in range(self.__m):
            temp = self.__sigmoid(w @ self.x[i])
            ans += self.x[i] * np.transpose([self.x[i]]) * temp * (1 - temp)
        # 最后求逆矩阵
        return np.linalg.pinv(ans)

    def solve(self):
        # 记录迭代轮数
        k = 0
        # 迭代轮数list和对应的losslist
        roundList = [k]
        lossList = []
        w = self.w_0
        lossList.append(Bo.loss(self.x, self.y, w, hyper=self.hyper))
        while True:
            gradient = self.__derivative(w)
            if np.linalg.norm(gradient) < self.delta:
                break
            k += 1
            # 使用迭代公式进行下一次迭代
            w = w - self.__second_derivative(w) @ gradient
            roundList.append(k)
            lossList.append(Bo.loss(self.x, self.y, w, hyper=self.hyper))

        return w, np.array(roundList), np.array(lossList)
