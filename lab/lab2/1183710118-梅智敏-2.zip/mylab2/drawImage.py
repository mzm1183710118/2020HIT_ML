import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D

import basicOperation as Bo
import newton


def ShowData(x, y):
    fig, axes = plt.subplots()

    # 得到2个维度的数组
    x1 = x[:, 1]
    x2 = x[:, 2]
    # 进一步划分pos和neg
    pos_x1 = x1[y == 1]
    neg_x1 = x1[y == 0]
    pos_x2 = x2[y == 1]
    neg_x2 = x2[y == 0]
    # 画出正反例的散点
    axes.scatter(pos_x1, pos_x2, color='g', label="Label1-pos")
    axes.scatter(neg_x1, neg_x2, color='r', label="Label2-neg")
    title = "sample number = " + str(len(y))
    axes.set_title(title, fontsize=16)
    axes.set_xlabel("$x_1$", fontsize=14)
    axes.set_ylabel("$x_2$", fontsize=14)
    axes.legend()
    plt.show()


def Regression(x, y, w):
    """
    画逻辑回归图像
    :param x: X matrix
    :param y: label集
    :param w: 线性分类器的系数
    :return: 画出图象
    """
    fig, axes = plt.subplots()

    # 得到2个维度的数组
    x1 = x[:, 1]
    x2 = x[:, 2]
    # 进一步划分pos和neg
    pos_x1 = x1[y == 1]
    neg_x1 = x1[y == 0]
    pos_x2 = x2[y == 1]
    neg_x2 = x2[y == 0]
    # 画出正反例的散点
    axes.scatter(pos_x1, pos_x2, color='g', label="Label1-pos")
    axes.scatter(neg_x1, neg_x2, color='r', label="Label2-neg")

    boundary_x1 = np.linspace(-2, 2, 1000)
    boundary_x2 = -(boundary_x1 * w[1] + w[0]) / w[2]
    # 画出预测直线
    axes.plot(boundary_x1, boundary_x2, color='black', label='predicted line')
    # 计算正确率
    accuracy = Bo.Accuracy(x, y, w)
    # 图的基本设置
    title = "sample number = " + str(len(y)) + ", Accuracy = " + str(accuracy)
    axes.set_title(title, fontsize=16)
    axes.set_xlabel("$x_1$", fontsize=14)
    axes.set_ylabel("$x_2$", fontsize=14)
    axes.legend()
    plt.show()


def NormalVSRegular(x,y,w1,w2):
    fig, axes = plt.subplots()

    # 得到2个维度的数组
    x1 = x[:, 1]
    x2 = x[:, 2]
    # 进一步划分pos和neg
    pos_x1 = x1[y == 1]
    neg_x1 = x1[y == 0]
    pos_x2 = x2[y == 1]
    neg_x2 = x2[y == 0]
    # 画出正反例的散点
    axes.scatter(pos_x1, pos_x2, color='g', label="Label1-pos")
    axes.scatter(neg_x1, neg_x2, color='r', label="Label2-neg")

    boundary_x1 = np.linspace(-2, 2, 1000)
    boundary_x2 = -(boundary_x1 * w1[1] + w1[0]) / w1[2]
    # 画出预测直线1
    axes.plot(boundary_x1, boundary_x2, color='blue', label='normal')
    # 画出预测直线2
    boundary_x3 = -(boundary_x1 * w2[1] + w2[0]) / w2[2]
    axes.plot(boundary_x1, boundary_x3, color='purple', label='regular')

    # 计算正确率
    accuracy = Bo.Accuracy(x, y, w1)
    accuracy2 = Bo.Accuracy(x, y, w2)
    # 图的基本设置
    title = "sample number = " + str(len(y)) + ", NormalAccuracy = " + str(accuracy)+", RegularAccuracy = " + str(accuracy2)
    axes.set_title(title, fontsize=16)
    axes.set_xlabel("$x_1$", fontsize=14)
    axes.set_ylabel("$x_2$", fontsize=14)
    axes.legend()
    plt.show()


def LossDecline(roundList, lossList):
    fig, axes = plt.subplots()
    axes.plot(roundList, lossList, "red")
    # 图的基本设置
    title = "LossDecline"
    axes.set_title(title, fontsize=16)
    axes.set_xlabel("$Round$", fontsize=14)
    axes.set_ylabel("$Loss$", fontsize=14)
    plt.show()


def ChooseHyper(Train_x, Train_y, Verify_x, Verify_y):
    hyperList = np.linspace(-30, 0, 31)
    lossList = []
    for index in range(len(hyperList)):
        hyper = np.exp(hyperList[index])
        # 初始化得到一个w
        w_0 = np.zeros(len(Train_x[0]) + 1)
        TrainX_matrix = Bo.XMatrix(Train_x)
        # 在测试集上得到w
        newTownObject = newton.MyNewton(TrainX_matrix, Train_y, w_0, hyper=hyper)
        result = newTownObject.solve()[0]
        # 在验证集上看loss
        VerifyX_matrix = Bo.XMatrix(Verify_x)
        loss = Bo.loss(VerifyX_matrix, Verify_y, result, hyper=0)
        lossList.append(loss)
    # 找到最佳的hyper
    bestIndex = np.where(lossList == np.min(lossList))[0][0]
    bestHyper = hyperList[bestIndex]
    print('最佳超参数为：ln(hyper) = ' + str(bestHyper))
    # 开始作图
    fig, ax = plt.subplots()
    ax.plot(hyperList, lossList, 'r-o', label="VerifySet")
    # 图的基本设置
    title = "loss of different hyper, best ln(hyper) = " + str(bestHyper)
    ax.set_title(title, fontsize=16)
    ax.set_xlabel("$hyper$", fontsize=14)
    ax.set_ylabel("$loss$", fontsize=14)
    ax.legend()
    plt.show()


def Skin3D(XMatrix, y, w, accuracy):
    fig = plt.figure()
    ax = Axes3D(fig)

    x1 = XMatrix[:, 1]
    x2 = XMatrix[:, 2]
    x3 = XMatrix[:, 3]
    # 进一步划分pos和neg
    pos_x1 = x1[y == 1]
    neg_x1 = x1[y == 0]
    pos_x2 = x2[y == 1]
    neg_x2 = x2[y == 0]
    pos_x3 = x3[y == 1]
    neg_x3 = x3[y == 0]

    # 画出正反例的散点
    ax.scatter(pos_x1, pos_x2, pos_x3, color='b', label="Label1-pos")
    ax.scatter(neg_x1, neg_x2, neg_x3, color='r', label="Label2-neg")

    # 画分界平面
    boundary_x1 = np.linspace(30, 500, 5000)
    boundary_x2 = np.linspace(30, 500, 5000)
    boundary_x1, boundary_x2 = np.meshgrid(boundary_x1, boundary_x2)
    boundary_x3 = -(boundary_x2 * w[2] + boundary_x1 * w[1] + w[0]) / w[3]

    ax.plot_surface(boundary_x1, boundary_x2, boundary_x3, color='yellow', label="Predicted boundary")
    # 图的基本设置
    title = "sample number = " + str(22055) + ", Accuracy = " + str(accuracy)
    ax.set_title(title, fontsize=16)
    ax.set_zlabel('$x_1$', fontdict={'size': 16, 'color': 'red'})
    ax.set_ylabel('$x_2$', fontdict={'size': 16, 'color': 'red'})
    ax.set_xlabel('$x_3$', fontdict={'size': 16, 'color': 'red'})
    plt.show()
