import numpy as np

import basicOperation as Bo
import drawImage as dI
import newton


Number = 1665
Train_x, Train_y, Verify_x, Verify_y, Test_x, Test_y = Bo.Data(Number, naive=True)
Number = 10000
bigTrain_x, bigTrain_y, bigVerify_x, bigVerify_y, bigTest_x, bigTest_y = Bo.Data(Number, naive=True)
# # 初始化得到一个w
# w_0 = np.zeros(len(Train_x[0]) + 1)
# x_matrix = Bo.XMatrix(Train_x)
# # 无正则项
# newTownObject = newton.MyNewton(x_matrix, Train_y, w_0, hyper=0)
# result, roundList, lossList = newTownObject.solve()
# print(result)
# # 有正则项
# newTownObject2 = newton.MyNewton(x_matrix, Train_y, w_0, hyper=np.exp(-3))
# result2, roundList2, lossList2 = newTownObject2.solve()
# print(result2)

# 展示数据点
# dI.ShowData(x_matrix,Train_y)
# 看迭代情况
# dI.LossDecline(roundList,lossList)
# 在测试集上看分类效果
# bigTestX_matrix = Bo.XMatrix(bigTest_x)
# dI.Regression(bigTestX_matrix, bigTest_y, result)
# dI.NormalVSRegular(bigTestX_matrix,bigTest_y,result,result2)
# 调整超参数：使用训练集的w，依据验证集的loss
# dI.ChooseHyper(Train_x,Train_y,bigVerify_x, bigVerify_y)

# 测试UCIData
path = "UCIdata/iris.csv"
Train_x, Train_y, Test_x, Test_y=Bo.ReadUCI(path)
w_0 = np.zeros(len(Train_x[0]) + 1)
x_matrix = Bo.XMatrix(Train_x)
newTownObject = newton.MyNewton(x_matrix, Train_y, w_0, hyper=0)
result = newTownObject.solve()[0]
print("训练样本数为："+str(len(Train_y)))
print("测试样本数为："+str(len(Test_y)))
print("w为"+str(result))
TestX_matrix = Bo.XMatrix(Test_x)
accuracy = Bo.Accuracy(TestX_matrix, Test_y, result)
print("准确率为："+str(accuracy))
# dI.Skin3D(TestX_matrix,Test_y,result,accuracy)



