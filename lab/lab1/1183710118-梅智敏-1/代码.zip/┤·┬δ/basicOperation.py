import numpy as np


def generateData(sigma, N):
    """
    Generate DataSet with noise
    Args:
        sigma: the variance of the noise
        N: the number of the Training-set
    """
    assert sigma > 0
    assert N > 0
    assert isinstance(N, int)

    X = np.linspace(0, 1, num=N)
    noise = np.random.normal(0, scale=sigma, size=X.shape)
    T = np.sin(2 * np.pi * X) + noise
    return X, T


def xMatrix(X, order=2):
    """
    Transform an ndarray's shape from (N, ) to (N, (order + 1)) .
    Args:
        X: an ndarray.
        order:int, order for polynomial.
    Returns:
        e.g.
        in:  [a b c]
        out: [[1 a a^2...a^order]
              [1 b b^2...b^order]
              [1 c c^2...c^order]]
    """
    assert X.ndim == 1
    assert isinstance(order, int)

    # 一维数组变二维
    cols = np.ones(len(X))[:, np.newaxis]
    for i in range(0, order):
        # 使用hstack水平连接时，要求2个数组的dim相等，故需要把cols[:, i]*X转换为二维数组
        cols = np.hstack((cols, (cols[:, i] * X)[:, np.newaxis]))
    return cols


def predictY(X, w, order):
    """
    根据数组X和系数数组w给出预测的Y数组
    Args:
        X: an ndarray shaped (N, )，代表各点的横坐标
        w: an ndarray shaped (order+1, )，代表多项式的各个系数
        order: The order of polynomials
    Returns:
        Y: an ndarray shaped (N,), 代表各点的纵坐标
    """
    X_matrix = xMatrix(X, order=order)

    return X_matrix @ w


def E_rms(Y, T, w, hp=0):
    """
    求出“根均方差”E_rms
    :param Y: 预测值矩阵
    :param T: 真实值矩阵
    :param w: 系数数组
    :param hp: 超参数
    :return: Y和T之间的根均方差的值
    """
    assert Y.ndim == 1
    assert Y.shape == T.shape

    if hp != 0:
        return np.sqrt(np.mean(np.square(Y - T)) + np.exp(hp) * (np.transpose(w) @ w) / len(T))
    else:
        return np.sqrt(np.mean(np.square(Y - T)))
