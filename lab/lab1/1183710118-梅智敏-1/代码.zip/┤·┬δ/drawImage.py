import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

import analytical
import basicOperation as Bo
import gradientDescent as gd
import conjugateGradient as cg


def DifferentSigmaImage(sigmaRange,N_train, N_test, layout):
    fig, axes = plt.subplots(*layout)

    for index in range(len(sigmaRange)):
        sigma = sigmaRange[index]
        X_test = np.linspace(0, 1, num=N_test)
        X_train, T = Bo.generateData(sigma, N_train)
        axTarget = axes[index // layout[1]][index % layout[1]]
        sns.regplot(X_train, T, fit_reg=False, color='b', label="sigma="+str(sigma), ax=axTarget)
        sns.lineplot(X_test, np.sin(2 * np.pi * X_test), color="g", label="$\\sin(2\\pi x)$",
                     ax=axTarget)
        # 图的相关设置
        title = 'Different sigma DataSet'
        props = {'title': title}
        axTarget.set(**props)

    plt.show()


def DifferentOrderImage(sigma, N_train, N_test, orderRange, layout):
    """
    draw不同order下的拟合曲线图像
    :param sigma: 噪声方差
    :param N_train: 训练集数据数目
    :param N_test: 测试集数据数目
    :param orderRange: order范围列表
    :param layout: 图像布局
    :return: 所需图像
    """
    X_train, T = Bo.generateData(sigma, N_train)
    X_test = np.linspace(0, 1, num=N_test)

    fig, axes = plt.subplots(*layout)
    for index in range(len(orderRange)):
        # 求出当前的order
        order = orderRange[index]
        # 确定目标坐标系
        axTarget = axes[index // layout[1]][index % layout[1]]
        # 使用regplot（）函数制作散点图, 您必须提供至少2个list-like：X轴和Y轴上的点的位置。
        # 默认情况下绘制线性回归拟合直线，可以使用fit_reg = False将其删除
        sns.regplot(X_train, T, fit_reg=False, color='b', label="Training Set", ax=axTarget)
        # 画真正的sin(2*np.pi*x)图线
        sns.lineplot(X_test, np.sin(2 * np.pi * X_test), color="g", label="$\\sin(2\\pi x)$",
                     ax=axTarget)
        # 画多项式拟合曲线
        anaSolution = analytical.AnalyticSolution(Bo.xMatrix(X_train, order), T)
        sns.lineplot(X_test, Bo.predictY(X_test, anaSolution.normal(), order), color="r", label="Analytical Solution",
                     ax=axTarget)

        # 图的相关设置
        title = "Order = " + str(order) + ", N_train = " + str(N_train) + ", N_test = " + str(N_test)
        props = {'title': title}
        axTarget.set(**props)

    plt.show()


def DifferentOrderErms(sigma, N_train, N_test, orderRange, hp = 0):
    """
    画出不同order下的Erms图像
    :param sigma: 噪声方差
    :param N_train: 训练集数据数目
    :param N_test: 测试集数据数目
    :param orderRange: order范围列表
    :param hp: 超参数
    :return: 所需的图像
    """
    X_train, T_train = Bo.generateData(sigma, N_train)
    X_test, T_test = Bo.generateData(sigma, N_test)
    ErmsTrainList = []
    ErmsTestList = []
    for order in orderRange:
        # 先通过TrainSet得到系数数组w，进而预测Y
        anaSolution = analytical.AnalyticSolution(Bo.xMatrix(X_train, order), T_train)
        w = anaSolution.normal()
        # 适配有无正则项的情况
        if(hp != 0):
            w = anaSolution.regular(np.exp(hp))

        Y_train = Bo.predictY(X_train, w, order)
        # 得到ErmsTrain并添加进List中
        ErmsTrain = Bo.E_rms(Y=Y_train, T=T_train, w=w, hp=hp)
        ErmsTrainList.append(ErmsTrain)

        Y_test = Bo.predictY(X_test, w, order)
        # 得到ErmsTest并添加进List中
        ErmsTest = Bo.E_rms(Y=Y_test, T=T_test, w=w, hp=hp)
        ErmsTestList.append(ErmsTest)

    fig, axes = plt.subplots()
    axes.plot(orderRange, ErmsTrainList, 'b-o', label="TrainingSet")
    axes.plot(orderRange, ErmsTestList, 'r-o', label="TestSet")
    title = "Erms for Different Order"

    props = {'title': title,
             'xlabel': 'Order',
             'ylabel': '$E_{RMS}$',
             }
    axes.set(**props)

    bestIndex = np.where(ErmsTestList == np.min(ErmsTestList))[0][0]
    bestOrder = orderRange[bestIndex]
    print("bestOrder:", bestOrder, np.min(ErmsTestList))
    axes.legend()
    axes.set_ylim(bottom=0)
    axes.set_xticks(np.arange(0, 10))

    plt.show()


def DifferentNTrainImage(sigma, N_trainRange, N_test, layout, order=9):
    fig, axes = plt.subplots(*layout)

    for index in range(len(N_trainRange)):
        N_train = N_trainRange[index]
        X_train, T = Bo.generateData(sigma, N_train)
        X_test = np.linspace(0, 1, num=N_test)

        # 确定目标坐标系
        axTarget = axes[index // layout[1]][index % layout[1]]
        # 使用regplot（）函数制作散点图, 您必须提供至少2个list-like：X轴和Y轴上的点的位置。
        # 默认情况下绘制线性回归拟合直线，可以使用fit_reg = False将其删除
        sns.regplot(X_train, T, fit_reg=False, color='b', label="Training Set", ax=axTarget)
        # 画真正的sin(2*np.pi*x)图线
        sns.lineplot(X_test, np.sin(2 * np.pi * X_test), color="g", label="$\\sin(2\\pi x)$",
                     ax=axTarget)
        # 画多项式拟合曲线
        anaSolution = analytical.AnalyticSolution(Bo.xMatrix(X_train, order), T)
        sns.lineplot(X_test, Bo.predictY(X_test, anaSolution.normal(), order), color="r", label="Analytical Solution",
                     ax=axTarget)

        # 图的相关设置
        title = "Order = " + str(order) + ", N_train = " + str(N_train) + ", N_test = " + str(N_test)
        props = {'title': title}
        axTarget.set(**props)

    plt.show()


def DifferentHpErms(sigma, N_train, N_test, hpRange):
    """
    画出不同超参数hp下的Erms图像
    :param sigma: 噪声方差
    :param N_train: 训练集数据数目
    :param N_test: 测试集数据数目
    :param hpRange: hp范围列表
    :return: 所需的图像
    """
    X_train, T_train = Bo.generateData(sigma, N_train)
    X_test, T_test = Bo.generateData(sigma, N_test)
    ErmsTrainList = []
    ErmsTestList = []
    for hp in hpRange:
        # 先通过TrainSet得到系数数组w，进而预测Y
        anaSolution = analytical.AnalyticSolution(Bo.xMatrix(X_train, 9), T_train)
        # 此处使用加入惩罚项的w,实际使用的超参数为e^hp
        w = anaSolution.regular(np.exp(hp))
        Y_train = Bo.predictY(X_train, w, 9)
        # 得到ErmsTrain并添加进List中
        ErmsTrain = Bo.E_rms(Y=Y_train, T=T_train, w=w, hp=hp)
        ErmsTrainList.append(ErmsTrain)

        Y_test = Bo.predictY(X_test, w, 9)
        # 得到ErmsTest并添加进List中
        ErmsTest = Bo.E_rms(Y=Y_test, T=T_test, w=w, hp=hp)
        ErmsTestList.append(ErmsTest)

    fig, axes = plt.subplots()
    axes.plot(hpRange, ErmsTrainList, 'b-o', label="TrainingSet")
    axes.plot(hpRange, ErmsTestList, 'r-o', label="TestSet")
    title = "Erms for Different Hyper"

    props = {'title': title,
             'xlabel': '$ln(Hyper)$',
             'ylabel': '$E_{RMS}$',
             }
    axes.set(**props)

    bestIndex = np.where(ErmsTestList == np.min(ErmsTestList))[0][0]
    bestHp = hpRange[bestIndex]
    print("bestHp:", bestHp, np.min(ErmsTestList))
    axes.legend()
    axes.set_ylim(bottom=0)
    plt.show()


def NormalVsRegular(sigma, N_train, N_test, hp):
    # 2个图像都使用相同的训练集和测试集
    X_train, T_train = Bo.generateData(sigma, N_train)
    X_test, T_test = Bo.generateData(sigma, N_test)
    layout = (1, 2)
    fig, axes = plt.subplots(*layout)

    # 下面画不加惩罚项的图
    sns.regplot(X_train, T_train, fit_reg=False, color='b', label="Training Set", ax=axes[0])
    # 画真正的sin(2*np.pi*x)图线
    sns.lineplot(X_test, np.sin(2 * np.pi * X_test), color="g", label="$\\sin(2\\pi x)$",
                 ax=axes[0])
    # 画多项式拟合曲线
    anaSolution = analytical.AnalyticSolution(Bo.xMatrix(X_train, order = 9), T_train)
    sns.lineplot(X_test, Bo.predictY(X_test, anaSolution.normal(), order = 9), color="r", label="Analytical-Normal",
                 ax=axes[0])
    axes[0].set_title('Without Regular term', fontsize=16)

    # 下面画加上惩罚项的图
    sns.regplot(X_train, T_train, fit_reg=False, color='b', label="Training Set", ax=axes[1])
    # 画真正的sin(2*np.pi*x)图线
    sns.lineplot(X_test, np.sin(2 * np.pi * X_test), color="g", label="$\\sin(2\\pi x)$",
                 ax=axes[1])
    # 画多项式拟合曲线
    anaSolution = analytical.AnalyticSolution(Bo.xMatrix(X_train, order=9), T_train)
    w = anaSolution.regular(np.exp(hp))
    sns.lineplot(X_test, Bo.predictY(X_test, w, order=9), color="r", label="Analytical-Regular",
                 ax=axes[1])
    axes[1].set_title('With Regular term, ' + '$ln(\\lambda)=$'+str(hp), fontsize=16)

    plt.show()


def DifferentAlphaErms(sigma, N_train, order, hp, alphaRange):
    X_train, T_train = Bo.generateData(sigma, N_train)
    colorList = ['b', 'g', 'r']

    fig, axes = plt.subplots()
    for alpha in alphaRange:
        # 选图线颜色
        index = np.where(alphaRange == alpha)[0][0]
        color = colorList[index]

        # 先通过TrainSet得到系数数组w，进而预测Y
        gdSolution = gd.GradientDescent(X_train, T_train, order, hp, alpha)
        w_0 = np.zeros(order+1)
        w, roundList, lossList = gdSolution.solve(w_0)

        axes.plot(roundList, lossList, color = color, label="$\\alpha = $"+str(alpha))

    title = "Iterative effect for Different alpha"
    props = {'title': title,
             'xlabel': '$Round$',
             'ylabel': '$E_{RMS}$',
             }
    axes.set(**props)
    axes.legend()
    axes.set_ylim(bottom=0)
    plt.show()


def GdVsRegular(sigma, N_train, N_test, order, hp, alpha):
    # 2个图像都使用相同的训练集和测试集
    X_train, T_train = Bo.generateData(sigma, N_train)
    X_test, T_test = Bo.generateData(sigma, N_test)
    fig, axes = plt.subplots()

    sns.regplot(X_train, T_train, fit_reg=False, color='b', label="Training Set", ax=axes)
    # 画真正的sin(2*np.pi*x)图线
    sns.lineplot(X_test, np.sin(2 * np.pi * X_test), color="g", label="$\\sin(2\\pi x)$",
                 ax=axes)
    # 画多项式拟合曲线
    anaSolution = analytical.AnalyticSolution(Bo.xMatrix(X_train, order=order), T_train)
    w = anaSolution.regular(np.exp(hp))
    sns.lineplot(X_test, Bo.predictY(X_test, w, order=order), color="r", label="Analytical-Regular",
                 ax=axes)

    gdSolution = gd.GradientDescent(X_train, T_train,order,hp,alpha)
    w_0 = np.zeros(order + 1)
    w2, roundList, lossList = gdSolution.solve(w_0)
    sns.lineplot(X_test, Bo.predictY(X_test, w2, order=order), color="purple", label="Gradient-Descent",
                 ax=axes)
    axes.set_title('Order = '+str(order) + ', N_train = '+str(N_train), fontsize=16)

    plt.show()


def DifferentNRound(sigma, N_trainRange, order, hp, alpha):
    fig, axes = plt.subplots()
    roundNumber = []
    for N_train in N_trainRange:
        X_train, T_train = Bo.generateData(sigma, N_train)
        gdSolution = gd.GradientDescent(X_train, T_train, order, hp, alpha)
        w_0 = np.zeros(order+1)
        w, roundList, lossList = gdSolution.solve(w_0)
        roundNumber.append(roundList[-1])

    axes.plot(N_trainRange, np.array(roundNumber))
    title = "Order = "+str(order)
    props = {'title': title,
             'xlabel': '$N_{train}$',
             'ylabel': '$Rounds$',
             }
    axes.set(**props)
    plt.show()


def DifferentOrderRound(sigma, N_train, orderRange, hp, alpha):
    fig, axes = plt.subplots()
    roundNumber = []
    X_train, T_train = Bo.generateData(sigma, N_train)

    for order in orderRange:
        gdSolution = gd.GradientDescent(X_train, T_train, order, hp, alpha)
        w_0 = np.zeros(order+1)
        w, roundList, lossList = gdSolution.solve(w_0)
        roundNumber.append(roundList[-1])

    axes.plot(orderRange, np.array(roundNumber))
    title = "N_train = "+str(N_train)
    props = {'title': title,
             'xlabel': '$Order$',
             'ylabel': '$Rounds$',
             }
    axes.set(**props)
    plt.show()


def ErmsForCG(sigma, N_train, order, hp):
    X_train, T_train = Bo.generateData(sigma, N_train)

    fig, axes = plt.subplots()

    cgSolution = cg.ConjugateGradient(X_train, T_train, order, hp)
    w_0 = np.zeros(order + 1)
    w, roundList, lossList = cgSolution.solve(cgSolution.A(), cgSolution.b(), w_0)

    axes.plot(roundList, lossList, label="conjugateGradient")

    title = "Iterative effect for N_train = " + str(N_train) + ', order = ' + str(order)
    props = {'title': title,
             'xlabel': '$Round$',
             'ylabel': '$E_{RMS}$',
             }
    axes.set(**props)
    axes.legend()
    axes.set_ylim(bottom=0)
    plt.show()


def CGVsRegular(sigma, N_train, N_test, order, hp):
    X_train, T_train = Bo.generateData(sigma, N_train)
    X_test, T_test = Bo.generateData(sigma, N_test)
    fig, axes = plt.subplots()

    sns.regplot(X_train, T_train, fit_reg=False, color='b', label="Training Set", ax=axes)
    # 画真正的sin(2*np.pi*x)图线
    sns.lineplot(X_test, np.sin(2 * np.pi * X_test), color="g", label="$\\sin(2\\pi x)$",
                 ax=axes)
    # 画多项式拟合曲线
    anaSolution = analytical.AnalyticSolution(Bo.xMatrix(X_train, order=order), T_train)
    w = anaSolution.regular(np.exp(hp))
    sns.lineplot(X_test, Bo.predictY(X_test, w, order=order), color="r", label="Analytical-Regular",
                 ax=axes)

    cgSolution = cg.ConjugateGradient(X_train, T_train,order,hp)
    w_0 = np.zeros(order + 1)
    w2, roundList, lossList = cgSolution.solve(cgSolution.A(), cgSolution.b(), w_0)

    sns.lineplot(X_test, Bo.predictY(X_test, w2, order=order), color="purple", label="Conjugate-Gradient",
                 ax=axes)

    axes.set_title('Order = ' + str(order) + ', N_train = ' + str(N_train), fontsize=16)

    plt.show()


def DifferentNRound_CG(sigma, N_trainRange, order, hp):
    fig, axes = plt.subplots()
    roundNumber = []
    for N_train in N_trainRange:
        X_train, T_train = Bo.generateData(sigma, N_train)
        cgSolution = cg.ConjugateGradient(X_train, T_train,order,hp)
        w_0 = np.zeros(order+1)
        w, roundList, lossList = cgSolution.solve(cgSolution.A(), cgSolution.b(), w_0)
        roundNumber.append(roundList[-1])

    axes.plot(N_trainRange, np.array(roundNumber))
    title = "Order = "+str(order)
    props = {'title': title,
             'xlabel': '$N_{train}$',
             'ylabel': '$Rounds$',
             }
    axes.set(**props)
    plt.show()


def DifferentOrderRound_CG(sigma, N_train, orderRange, hp):
    fig, axes = plt.subplots()
    roundNumber = []
    X_train, T_train = Bo.generateData(sigma, N_train)

    for order in orderRange:
        cgSolution = cg.ConjugateGradient(X_train, T_train,order,hp)
        w_0 = np.zeros(order + 1)
        w, roundList, lossList = cgSolution.solve(cgSolution.A(), cgSolution.b(), w_0)
        roundNumber.append(roundList[-1])

    axes.plot(orderRange, np.array(roundNumber))
    title = "N_train = " + str(N_train)
    props = {'title': title,
             'xlabel': '$Order$',
             'ylabel': '$Rounds$',
             }
    axes.set(**props)
    axes.legend()
    plt.show()