import drawImage as dI
import statistics as sta
import numpy as np

sigma = 0.3  # noise的方差
N_train = 10  # 训练样本的数量
N_test = 100 * (N_train - 1) + 2  # 测试样本的数量(保证只有0,1点与训练集重复)
orderRange = range(1, 10)  # 多项式的阶
sigmaRange = np.array([0.1, 0.2, 0.3, 0.4])
layout = (3, 2)
# 展示：不同siama的图
# dI.DifferentSigmaImage(sigmaRange,N_train,N_test,layout)
# 展示：固定N_train,不同order时的拟合曲线
# dI.DifferentOrderImage(sigma, N_train, N_test, orderRange, layout)
# orderRange = range(10)
# 展示: 固定N_train,不同order时的Erms图线
# dI.DifferentOrderErms(sigma, N_train, N_test, orderRange)
# 寻找最佳order
# x = sta.BestOrder(sigma, N_train, N_test, orderRange, times=100)
# print(x)
# 展示：固定order=9，不同N_train时的拟合曲线
N_trainRange = range(10, 130, 20)
# dI.DifferentNTrainImage(sigma, N_trainRange, N_test, layout)
hpRange = range(-60, 1, 1)
# 展示：固定order = 9， 不同hp时的Erms
# dI.DifferentHpErms(sigma, N_train, N_test, hpRange)
# 进行times次实验，寻找最佳hp——经过实验得到最佳hp为e^(-8)
# x = sta.BestHp(sigma, N_train, N_test, hpRange, times=203)
# print(x)
# 展示：order = 9时，有无正则项的图线区别
# dI.NormalVsRegular(sigma, N_train, N_test, hp=-8)
# dI.DifferentOrderErms(sigma, N_train, N_test, orderRange, hp=-8)
# alphaRange = np.array([0.125, 0.126, 0.127])
# dI.DifferentAlphaErms(sigma, N_train, 3, hp = -8, alphaRange = alphaRange)
alpha = 0.01
# dI.GdVsRegular(sigma, N_train, N_test, 9, -8, alpha)
# dI.ErmsForCG(sigma, N_train = 10, order=9, hp=-8)
# dI.DifferentNRound(sigma, N_trainRange, 9, -8, alpha)
dI.DifferentOrderRound(sigma, N_train=10, orderRange=orderRange, hp = -8, alpha=alpha)
# dI.CGVsRegular(sigma,N_train,N_test, 9, -8)
# dI.DifferentNRound_CG(sigma,N_trainRange, 9, -8)
# dI.DifferentOrderRound_CG(sigma,N_train, orderRange,-8)
