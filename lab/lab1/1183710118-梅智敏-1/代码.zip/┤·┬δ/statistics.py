from collections import Counter
import numpy as np
import analytical
import basicOperation as Bo


def BestOrder(sigma, N_train, N_test, orderRange, times=100):
    """
    找到最佳阶数Order，返回（order，counter）的tuple
    :param sigma: 噪声方差
    :param N_train: 训练集数据数目
    :param N_test: 测试集数据数目
    :param orderRange: order范围列表
    :param times: 进行的实验次数
    :return: times次实验中被选为最佳的次数最多的阶数order，以及被选为最佳的次数counter，所组成的tuple
    """
    bestOrderList = []
    # 做times次实验
    for i in range(times):
        X_train, T_train = Bo.generateData(sigma, N_train)
        X_test, T_test = Bo.generateData(sigma, N_test)
        ErmsTrainList = []
        ErmsTestList = []
        for order in orderRange:
            # 先通过TrainSet得到系数数组w，进而预测Y
            anaSolution = analytical.AnalyticSolution(Bo.xMatrix(X_train, order), T_train)
            w = anaSolution.normal()
            Y_train = Bo.predictY(X_train, w, order)
            # 得到ErmsTrain并添加进List中
            ErmsTrain = Bo.E_rms(Y=Y_train, T=T_train, w=w)
            ErmsTrainList.append(ErmsTrain)

            Y_test = Bo.predictY(X_test, w, order)
            # 得到ErmsTest并添加进List中
            ErmsTest = Bo.E_rms(Y=Y_test, T=T_test, w=w)
            ErmsTestList.append(ErmsTest)

        bestIndex = np.where(ErmsTestList == np.min(ErmsTestList))[0][0]
        bestOrder = orderRange[bestIndex]
        bestOrderList.append(bestOrder)

    collectionOrders = Counter(bestOrderList)
    most_counterNum = collectionOrders.most_common(1)
    return most_counterNum[0]


def BestHp(sigma, N_train, N_test, hpRange, times=100):
    """
    找到最佳hp，返回（hp，counter）的tuple
    :param sigma: 噪声方差
    :param N_train: 训练集数据数目
    :param N_test: 测试集数据数目
    :param hpRange: hp范围列表
    :param times: 进行的实验次数
    :return: times次实验中被选为最佳的次数最多的超参数hp，以及被选为最佳的次数counter，所组成的tuple
    """
    bestHpList = []
    # 做times次实验
    for i in range(times):
        X_train, T_train = Bo.generateData(sigma, N_train)
        X_test, T_test = Bo.generateData(sigma, N_test)
        ErmsTrainList = []
        ErmsTestList = []
        for hp in hpRange:
            # 先通过TrainSet得到系数数组w，进而预测Y
            anaSolution = analytical.AnalyticSolution(Bo.xMatrix(X_train, order=9), T_train)
            w = anaSolution.regular(np.exp(hp))
            Y_train = Bo.predictY(X_train, w, order=9)
            # 得到ErmsTrain并添加进List中
            ErmsTrain = Bo.E_rms(Y=Y_train, T=T_train, w=w, hp=hp)
            ErmsTrainList.append(ErmsTrain)

            Y_test = Bo.predictY(X_test, w, order=9)
            # 得到ErmsTest并添加进List中
            ErmsTest = Bo.E_rms(Y=Y_test, T=T_test, w=w, hp=hp)
            ErmsTestList.append(ErmsTest)

        bestIndex = np.where(ErmsTestList == np.min(ErmsTestList))[0][0]
        bestHp = hpRange[bestIndex]
        bestHpList.append(bestHp)

    collectionHps = Counter(bestHpList)
    most_counterNum = collectionHps.most_common(5)
    return most_counterNum
