import numpy as np
import basicOperation as Bo


class ConjugateGradient(object):
    def __init__(self, X, T, order, hp, delta=1e-5):
        self.X = X
        self.T = T
        self.order = order
        self.hp = hp
        self.delta = delta

    def A(self):
        # 求出代价函数E(w)写成二次型后的A矩阵
        X_matrix = Bo.xMatrix(self.X, self.order)
        return X_matrix.T @ X_matrix + np.exp(self.hp)

    def b(self):
        # 求出代价函数E(w)写成二次型后的b矩阵
        X_matrix = Bo.xMatrix(self.X, self.order)
        return X_matrix.T @ self.T

    def __loss(self, w):
        # 求当前loss，以Erms来衡量
        Y = Bo.predictY(self.X, w, self.order)
        return Bo.E_rms(Y, self.T, w, self.hp)

    def solve(self, A, b, w):
        """
        共轭梯度法求解方程组Aw = b
        :param A: 代价函数E(w)写成二次型后的A矩阵
        :param b: 代价函数E(w)写成二次型后的b矩阵
        :param w: 初始向量w，通常用全零向量
        :return: 该方程组的解w, 迭代轮数列表， lossList组成的三元组
        """
        k = 0   # 迭代轮数计数器
        roundList = [k]
        lossList = [self.__loss(w)]

        grad = np.dot(A, w) - b
        p = -grad
        while True:
            k += 1
            roundList.append(k)

            if abs(np.sum(p)) < self.delta:
                # 记录下最后一次的loss
                lossList.append(self.__loss(w))
                break
            gradSquare = np.dot(grad, grad)
            Ap = np.dot(A, p)
            alpha = gradSquare / np.dot(p, Ap)
            w += alpha * p
            newGrad = grad + alpha * Ap
            beta = np.dot(newGrad, newGrad) / gradSquare
            p = -newGrad + beta * p
            grad = newGrad

            # 记录当前的loss并加入列表
            lossList.append(self.__loss(w))

        return w, np.array(roundList), np.array(lossList)
