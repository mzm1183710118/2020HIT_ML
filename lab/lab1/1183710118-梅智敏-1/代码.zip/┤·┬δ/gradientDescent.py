import numpy as np
import basicOperation as Bo


class GradientDescent(object):
    def __init__(self, X, T, order, hp, alpha, delta=1e-2):

        self.X = X
        self.T = T
        self.order = order
        self.hp = hp
        self.alpha = alpha
        self.delta = delta

    def __loss(self, w):
        """
        求出当前w所对应的loss，使用E_RMS来量化
        :param w: 当前的w
        :return: 当前的loss
        """
        Y = Bo.predictY(self.X, w, self.order)
        return Bo.E_rms(Y, self.T, w, self.hp)

    def __gradient(self, w):
        """
        求代价函数的梯度
        :param w: 当前的w
        :return: 当前的梯度
        """
        X_matrix = Bo.xMatrix(self.X, self.order)
        return np.transpose(X_matrix) @ X_matrix @ w + np.exp(self.hp) * w - X_matrix.T @ self.T

    def solve(self, w_0):
        """
        梯度下降法求解w
        :param w_0: w的初始值，通常取全零向量
        :return: 优化解w, 迭代轮数列表， lossList组成的三元组
        """

        # w表示当前的优化解
        w = w_0
        gradient = self.__gradient(w)
        # 记录迭代轮数
        k = 0

        roundList = [k]
        lossList = [self.__loss(w_0)]

        while not np.all(np.absolute(gradient) <= self.delta):
            if k > 100000:
                break
            else:
                k += 1
                w = w - self.alpha * gradient
                gradient = self.__gradient(w)
                roundList.append(k)
                lossList.append(self.__loss(w))

        return w, np.array(roundList), np.array(lossList)
