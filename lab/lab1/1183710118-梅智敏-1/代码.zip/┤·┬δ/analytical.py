import numpy as np


class AnalyticSolution(object):

    def __init__(self, X_matrix, T):
        """
        generate an Object of Analytic_Solution
        Args:
            X_matrix: a matrix shaped (N, (order+1)) for X
            T: a ndarray of true values
        """
        self.X_matrix = X_matrix
        self.T = T

    def normal(self):
        """
        无惩罚项求解析解
        Returns:
                系数数组w, shaped (order+1, 1)
        """
        return np.linalg.pinv(self.X_matrix) @ self.T

    def regular(self, hp):
        """
        加入惩罚项求解析解
        :param hp:
                惩罚项中的超参数lambda
        :return:
                系数数组w，shaped (order+1, 1)
        """
        assert hp >= 0

        # 利用np.linalg.solve(A,B)求解w
        return np.linalg.solve(self.X_matrix.T @ self.X_matrix + hp * np.identity(len(self.X_matrix.T)),
                               self.X_matrix.T @ self.T)
