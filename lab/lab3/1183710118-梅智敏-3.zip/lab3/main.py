import k_means
import basicOperation as Bo
import drawImage as dI
import numpy as np
import gmm

k = 3
# means = [[2, 4], [3, -6], [-2, -4]]
# number = [100, 200, 300]
# data = Bo.generate_data(means, number, k)
# # 使用K-means
# km = k_means.KMeans(data, k)
# mu_random, c_random = km.RandomCenterAnswer()
# # print("随机初始点的轮廓系数为", Bo.SilhouetteCoefficient(c_random))
# print("-----------------")
# mu_NotRandom, c_NotRandom = km.NotRandomCenterAnswer()
# # print("优化初始但的轮廓系数为", Bo.SilhouetteCoefficient(c_NotRandom))
# dI.KMeansImage(k, mu_random, c_random, mu_NotRandom, c_NotRandom)

data, X1, X2, X3, true_mu, true_Var = Bo.GMMData()
dI.ShowGMMData(X1, X2, X3)
# 使用GMM
GMM = gmm.GaussianMixtureModel(data, k=k)
# 前3个为模型参数，第四个为聚类的簇结果，第五个数迭代轮数的List，第六个是似然值List
alpha, mu, sigma, c, ROUNDList, likelihoodList = GMM.solve()
print("center: \n", mu)
print("各个分布的权重为", alpha)
Bo.printSigma(sigma)
# 既将sigma从字典转为list， 又将协方差矩阵的多余cov去除
sigma = Bo.ChangeVar(sigma)
dI.GMMImage(c, mu, sigma, true_mu, true_Var)
print("GMM的轮廓系数为", Bo.SilhouetteCoefficient(c))
dI.LikeHoodChange(np.array(ROUNDList), np.array(likelihoodList))

# iris_data = Bo.ReadUCI("UCIdata/iris.csv")
# GMM = gmm.GaussianMixtureModel(iris_data, k=3)
# alpha, mu, sigma, c, ROUNDList, likelihoodList = GMM.solve()
# print("center: \n", mu)
# print("各个分布的权重为", alpha)
# Bo.printSigma(sigma)
# # print("对IRIS数据集使用GMM的轮廓系数为", Bo.SilhouetteCoefficient(c))
# # 展示似然值随着迭代轮数的变化
# dI.LikeHoodChange(np.array(ROUNDList), np.array(likelihoodList))

