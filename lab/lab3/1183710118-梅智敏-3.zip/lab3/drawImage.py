import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Ellipse


def ShowGMMData(X1, X2, X3):
    fig, ax = plt.subplots()
    ax.scatter(X1[:, 0], X1[:, 1], marker="x", label="class 1")
    ax.scatter(X2[:, 0], X2[:, 1], marker="x", label="class 2")
    ax.scatter(X3[:, 0], X3[:, 1], marker="x", label="class 3")
    ax.set_xlabel("$x$", fontsize=14)
    ax.set_ylabel("$y$", fontsize=14)
    ax.set_title("The GMM DataSet", fontsize=16)
    ax.legend()
    plt.show()


def KMeansImage(k, mu_random, c_random, mu_NotRandom, c_NotRandom):
    fig, axes = plt.subplots(1, 2)
    axes[0].set_title("K-Means:random Initialisation", fontsize=16)
    for i in range(k):
        axes[0].scatter(np.array(c_random[i])[:, 0], np.array(c_random[i])[:, 1], marker="x", label="class"+str(i + 1))
    axes[0].scatter(mu_random[:, 0], mu_random[:, 1], facecolor="red", edgecolor="black", label="center")
    axes[0].set_xlabel("$x$", fontsize=14)
    axes[0].set_ylabel("$y$", fontsize=14)
    axes[0].legend()

    axes[1].set_title("K-Means:optimize Initialisation", fontsize=16)
    for i in range(k):
        axes[1].scatter(np.array(c_NotRandom[i])[:, 0], np.array(c_NotRandom[i])[:, 1], marker="x", label="class"+str(i + 1))
    axes[1].scatter(mu_NotRandom[:, 0], mu_NotRandom[:, 1], facecolor="red", edgecolor="black", label="center")
    axes[1].set_xlabel("$x$", fontsize=14)
    axes[1].set_ylabel("$y$", fontsize=14)
    axes[1].legend()
    plt.show()


def GMMImage(c, Mu, Var, Mu_true=None, Var_true=None):
    n_clusters = len(Mu)
    ax = plt.gca()
    # 画中心点
    ax.scatter(Mu[:, 0], Mu[:, 1], facecolor="red", edgecolor="black", label="center")
    # 画数据点
    for i in range(n_clusters):
        ax.scatter(np.array(c[i])[:, 0], np.array(c[i])[:, 1], marker="x", label="class" + str(i + 1))
    # 画GMM学习出的高斯椭圆
    for i in range(n_clusters):
        plot_args = {'fc': 'None', 'lw': 2, 'ls': ':', 'edgecolor': "red"}
        ellipse = Ellipse(Mu[i], 3 * Var[i][0], 3 * Var[i][1], **plot_args)
        ax.add_patch(ellipse)
    # 画真实的高斯椭圆
    if (Mu_true is not None) & (Var_true is not None):
        for i in range(n_clusters):
            plot_args = {'fc': 'None', 'lw': 2, 'alpha': 0.5, 'edgecolor': "purple"}
            ellipse = Ellipse(Mu_true[i], 3 * Var_true[i][0], 3 * Var_true[i][1], **plot_args)
            ax.add_patch(ellipse)
    ax.set_title("GMM clustering effect", fontsize=16)
    ax.set_xlabel("$x$", fontsize=14)
    ax.set_ylabel("$y$", fontsize=14)
    ax.legend()
    plt.show()


def LikeHoodChange(ROUNDList, likelihoodList):
    fig, axes = plt.subplots()
    axes.set_title("Change of the Likelihood", fontsize=16)
    axes.plot(ROUNDList, likelihoodList, color="red")
    axes.set_xlabel("$ROUND$", fontsize=14)
    axes.set_ylabel("$LikeHood$", fontsize=14)
    plt.show()
