import numpy as np
import collections
import random
import basicOperation as Bo


class KMeans(object):
    def __init__(self, data, k, delta=1e-6):
        self.data = data
        self.k = k
        self.delta = delta
        self.dataNumber, self.dimNumber = data.shape
        self.__mu = []
        # self.sample_assignments = [-1] * self.dataNumber

    def RandomCenterAnswer(self):
        """ 随机选择k个顶点作为初始簇中心点 """
        self.__mu = self.data[random.sample(range(self.dataNumber), self.k)]
        return self.Solve()

    def NotRandomCenterAnswer(self):
        """ 随机选择第一个簇中心点 再选出下一个和已有中心点距离之和最大的点作为新中心点 这样不断循环便可找到K个初始点 """
        # 随机选第1个初始点
        index = np.random.randint(0, self.k)
        mu = [self.data[index]]
        # 依次选择与当前mu中样本点距离之和最大的点作为初始簇中心点
        for times in range(self.k-1):
            distanceSum = []
            for i in range(self.dataNumber):
                distanceSum.append(np.sum([Bo.distance(self.data[i], mu[j]) for j in range(len(mu))]))
            mu.append(self.data[np.argmax(distanceSum)])

        self.__mu = np.array(mu)
        return self.Solve()

    # 用K-means求解，返回K个簇和它们的中心点
    def Solve(self):
        ROUND = 0
        while True:
            # 打印当前的迭代情况
            print("K-means : ROUND " + str(ROUND))
            print("The centers are : \n", self.__mu)
            ROUND += 1

            c = collections.defaultdict(list)
            # 对每个数据点进行聚类
            for i in range(self.dataNumber):
                # 求出每个数据点到各个中心点的距离
                dij = [Bo.distance(self.data[i], self.__mu[j]) for j in range(self.k)]
                # 将当前数据点归类到距离最近的那一簇中
                labelIndex = np.argmin(dij)
                c[labelIndex].append(self.data[i].tolist())
                # self.sample_assignments[i] = labelIndex

            # 对每个中心点进行更新
            new_mu = np.array([np.mean(c[i], axis=0).tolist() for i in range(self.k)])
            # 检测loss是否达到精度要求
            loss = np.sum(Bo.distance(self.__mu[i], new_mu[i]) for i in range(self.k))
            if loss > self.delta:
                self.__mu = new_mu
                continue
            else:
                break
        return self.__mu, c
