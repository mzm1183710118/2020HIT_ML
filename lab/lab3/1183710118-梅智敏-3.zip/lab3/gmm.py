import numpy as np
from scipy.stats import multivariate_normal
import collections
import random
import basicOperation as Bo


class GaussianMixtureModel(object):
    """ 高斯混合聚类EM算法 """

    def __init__(self, data, k=3, delta=1e-12, max_iteration=1000):
        self.data = data
        self.k = k
        self.delta = delta
        self.max_iteration = max_iteration
        self.dataNumber, self.dimNumber = self.data.shape
        # 初始化各个分布的均值、协方差矩阵、各个分布的权值
        self.__mu, self.__sigma, self.__alpha = self.InitParams()
        # 一个N*K矩阵，代表第j个数据点来自第k个分布的概率，是隐参数
        self.__gamma = None

        self.sample_assignments = None
        self.c = collections.defaultdict(list)

    def InitParams(self):
        # mu = np.array(self.data[random.sample(range(self.dataNumber), self.k)])
        # 随机选择k个点作为初始点 极易陷入局部最小值
        # 初始化均值
        index = np.random.randint(0, self.k)
        mu = [self.data[index]]
        # 依次选择与当前mu中样本点距离之和最大的点作为初始簇中心点
        for times in range(self.k - 1):
            distanceSum = []
            for i in range(self.dataNumber):
                distanceSum.append(np.sum([Bo.distance(self.data[i], mu[j]) for j in range(len(mu))]))
            mu.append(self.data[np.argmax(distanceSum)])

        # 初始化每个分布的协方差矩阵
        sigma = collections.defaultdict(list)
        for i in range(self.k):
            # 每个分布的协方差矩阵都默认为对角阵，且每个维度的方差默认为0.1
            sigma[i] = np.eye(self.dimNumber, dtype=float) * 0.1

        # 初始化每个分布的权值
        alpha = np.ones(self.k) * (1.0 / self.k)
        return mu, sigma, alpha

    # 计算似然值
    def logLH(self):
        data = self.data
        alpha = self.__alpha
        Mu = self.__mu
        Var = self.__sigma
        n_points, n_clusters = len(data), len(alpha)
        pdfs = np.zeros((n_points, n_clusters))
        for i in range(n_clusters):
            pdfs[:, i] = alpha[i] * multivariate_normal.pdf(data, Mu[i], np.diag(Var[i]))
        return np.mean(np.log(pdfs.sum(axis=1)))

    # 求出概率密度矩阵(N,K)
    def probability_density(self):
        likelihoods = np.zeros((self.dataNumber, self.k))
        for i in range(self.k):
            # pdf为概率密度函数
            likelihoods[:, i] = multivariate_normal.pdf(self.data, self.__mu[i], self.__sigma[i])
        return likelihoods

    # E步
    def E_step(self):
        # 计算概率密度和alpha之积
        weighted = self.probability_density() * self.__alpha
        sum_likelihoods = np.expand_dims(np.sum(weighted, axis=1), axis=1)
        # 求出gamma，即分模型对观测数据的“响应度矩阵” (N*K)
        self.__gamma = weighted / sum_likelihoods
        self.sample_assignments = self.__gamma.argmax(axis=1)
        # 依据响应度将每个数据点进行聚类
        for i in range(self.dataNumber):
            self.c[self.sample_assignments[i]].append(self.data[i].tolist())

    # M步
    def M_step(self):
        # 在隐参数保持不变的情况下使用极大似然法更新模型参数
        for i in range(self.k):
            # 提取每一列 作为列向量 (m, 1)
            gamma = np.expand_dims(self.__gamma[:, i], axis=1)
            mean = (gamma * self.data).sum(axis=0) / gamma.sum()
            covariance = (self.data - mean).T.dot((self.data - mean) * gamma) / gamma.sum()
            # 更新均值和方差
            self.__mu[i], self.__sigma[i] = mean, covariance
        # 更新各个分布的权值
        self.__alpha = self.__gamma.sum(axis=0) / self.dataNumber

    def solve(self):
        print("GMM")
        ROUNDList = []
        likelihoodList = []
        old_alpha = self.__alpha
        old_mu = self.__mu
        old_sigma = self.__sigma
        # 不断迭代，以求解
        for i in range(self.max_iteration):
            # 依次执行E和M步
            self.E_step()
            self.M_step()
            # 判断是否收敛
            diff = np.linalg.norm(old_alpha - self.__alpha) \
                   + np.linalg.norm(np.array(old_mu) - np.array(self.__mu)) \
                   + np.sum([np.linalg.norm(np.array(old_sigma[i]) - np.array(self.__sigma[i])) for i in range(self.k)])
            # print("diff: ", diff)
            ROUNDList.append(i)
            # 就算每步迭代的似然值
            likelihoodList.append(self.logLH())
            # 未达到精度要求，则更新模型参数
            if diff > self.delta:
                old_alpha = self.__alpha
                old_mu = self.__mu
                old_sigma = self.__sigma
                continue
            else:
                break
        return self.__alpha, np.array(self.__mu), self.__sigma, self.c, ROUNDList, likelihoodList
