import numpy as np
import pandas as pd


def generate_data(sample_means, sample_number, k):
    """ 生成多簇二维高斯分布数据
    :argument k k类
    :argument sample_means k类数据的均值 如[[2, 4],[-2, -4], [3, -6]]
    :argument sample_number k类数据的数量 如[100, 200, 300]
    """
    # 协方差矩阵设置为对角阵，且2个维度的方差均为0.1
    cov = [[0.1, 0], [0, 0.1]]
    data = []
    for index in range(k):
        for times in range(sample_number[index]):
            data.append(np.random.multivariate_normal(
                [sample_means[index][0], sample_means[index][1]], cov).tolist())
    return np.array(data)


# 求2点之间欧氏距离（二范数）
def distance(x1, x2):
    return np.linalg.norm(x1 - x2)


def SilhouetteCoefficient(c):
    N = 0
    SList = []
    for i in range(len(c)):
        N += len(c[i])
        for j in range(len(c[i])):
            # 遍历每个点
            point = np.array(c[i])[j]
            a = 0
            for k in range(len(c[i])):
                # 遍历其他同簇点
                otherPoint = np.array(c[i])[k]
                a += distance(point, otherPoint) / len(c[i])

            # 计算b
            b = []
            for m in range(len(c)):
                # 找不同簇
                if m != i:
                    tmp = 0
                    for n in range(len(c[m])):
                        otherPoint = np.array(c[m])[n]
                        tmp += distance(point, otherPoint) / len(c[m])
                    b.append(tmp)
            b = np.array(b).min()

            s = (b - a) / max(a, b)
            SList.append(s)
    result = np.array(SList).mean()
    return result


def ReadUCI(path):
    data_set = pd.read_csv(path)  # linux 相对路径
    x = data_set.drop('label', axis=1)
    dataX = np.array(x, dtype=float)
    return dataX


def GMMData():
    # 第一簇的数据
    num1, mu1, var1 = 100, [0.5, 0.5], [1, 3]
    X1 = np.random.multivariate_normal(mu1, np.diag(var1), num1)
    # 第二簇的数据
    num2, mu2, var2 = 200, [5.5, 2.5], [2, 2]
    X2 = np.random.multivariate_normal(mu2, np.diag(var2), num2)
    # 第三簇的数据
    num3, mu3, var3 = 300, [1, 7], [6, 2]
    X3 = np.random.multivariate_normal(mu3, np.diag(var3), num3)
    # 合并在一起
    X = np.vstack((X1, X2, X3))
    true_mu = [mu1, mu2, mu3]
    true_Var = [var1, var2, var3]
    return X, X1, X2, X3, true_mu, true_Var


def printSigma(sigma):
    for i in range(len(sigma)):
        array = sigma[i]
        print("第"+str(i+1)+"个分布的协方差矩阵为：\n", array)


def ChangeVar(sigma):
    result = []
    for i in range(len(sigma)):
        cov = []
        array = sigma[i]
        num1 = array[0][0]
        num2 = array[1][1]
        cov.append(num1)
        cov.append(num2)
        result.append(cov)
    return result


