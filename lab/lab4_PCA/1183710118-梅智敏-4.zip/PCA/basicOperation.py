from PIL import Image

import cv2
import numpy as np
import math
import os
import matplotlib.pyplot as plt


def generate_data(data_dimension, number=100):
    """
    自己生成2维或者3维高斯分布的数据集
    :param data_dimension: 数据的维度
    :param number: 样本点的数目
    :return: D * N 的数据矩阵, D是维度，M是样本数目
    """
    if data_dimension is 2:
        mean = [-3, 4]
        # 让某个维度的方差远小于其他维度
        cov = [[1, 0], [0, 0.01]]
    elif data_dimension is 3:
        mean = [2, 8, -5]
        cov = [[0.01, 0, 0], [0, 1, 0], [0, 0, 1]]
    else:
        assert False

    # 产生shape = (D,M)的数据矩阵
    data = np.random.multivariate_normal(mean, cov, size=number).T
    # if data_dimension is 3:
    #     # 绕z轴旋转数据点
    #     data = rotate(data, 40 * np.pi / 180, 'z')
    return data


def rotate(X, theta=0, axis='x'):
    """
    :param X: 数据矩阵 X.shape = (D, N)
    :param theta: 旋转的弧度
    :param axis: 旋转轴，合法值为'x','y'或'z'
    :return:
    """
    if axis == 'x':
        rotate_matrix = [[1, 0, 0], [0, np.cos(theta), -np.sin(theta)], [0, np.sin(theta), np.cos(theta)]]
        return np.dot(rotate_matrix, X)
    elif axis == 'y':
        rotate_matrix = [[np.cos(theta), 0, np.sin(theta)], [0, 1, 0], [-np.sin(theta), 0, np.cos(theta)]]
        return np.dot(rotate_matrix, X)
    elif axis == 'z':
        rotate_matrix = [[np.cos(theta), -np.sin(theta), 0], [np.sin(theta), np.cos(theta), 0], [0, 0, 1]]
        return np.dot(rotate_matrix, X)
    else:
        assert False


def PCA(data, k):
    """
    将数据data从D维降到k维
    :param data: 数据矩阵(D*N),D表示维度，N表示样本点的个数
    :param k: 把数据降到目标维数
    :return: 零均值化之后的数据矩阵，特征值矩阵，均值矩阵, 重构之后的数据矩阵（仍然 D*N）
    """
    dim = data.shape[0]
    mean = np.mean(data, axis=1)
    c_data = np.zeros(data.shape)
    for i in range(dim):
        # 零均值化后得到c_data (D*N)
        c_data[i] = data[i] - mean[i]
    # 求出协方差矩阵
    covMat = np.dot(c_data, c_data.T)
    # 对协方差矩阵covMat(D*D)求特征值和特征向量
    # eigenVectors的每一列对应一个特征向量
    eigenValues, eigenVectors = np.linalg.eig(covMat)
    # 特征值排序
    eigValIndex = np.argsort(eigenValues)
    # 取前k个特征值对应的特征向量 shape = (D*k)
    rightEigenVector = eigenVectors[:, eigValIndex[:-(k + 1):-1]]
    # 一旦降维维度超过某个值，特征向量矩阵将出现复向量，对其保留实部
    rightEigenVector = np.real(rightEigenVector)
    # 计算降维后的数据(K*N)
    tmp_data = np.dot(rightEigenVector.T, c_data)
    # 重构之后的数据
    recon_data = np.zeros(data.shape)
    for i in range(dim):
        recon_data[i] = np.dot(rightEigenVector[i], tmp_data) + mean[i]
    return c_data, rightEigenVector, mean, recon_data


def read_faces(file_path, size):
    """
    从图像文件中读取人脸数据
    :param file_path: 文件路径
    :param size: 压缩读取的大小
    :return: 人脸数据矩阵 （D*N）D表示维度，N表示样本点数目
    """
    file_list = os.listdir(file_path)
    data = []
    i = 1
    plt.figure(figsize=size)
    for file in file_list:
        path = os.path.join(file_path, file)
        plt.subplot(2, 2, i)
        with open(path) as f:
            # 读取图像
            img = cv2.imread(path)
            # 压缩图像至size大小
            img = cv2.resize(img, size)
            # RBG图转换为灰度图
            img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            # 展示灰度值图像
            plt.imshow(img_gray)
            h, w = img_gray.shape
            # 对(h,w)的图像数据拉平
            img_col = img_gray.reshape(h * w)
            data.append(img_col)
        i += 1
    plt.show()
    return np.array(data).T


def psnr(img1Data, img2Data):
    mse = np.mean((img1Data / 255. - img2Data / 255.) ** 2)
    if mse < 1.0e-10:
        return 100
    PIXEL_MAX = 1
    # 使用的信噪比公式为20 log_10^(MAX/sqrt(MSE))
    return 20 * math.log10(PIXEL_MAX / math.sqrt(mse))
