import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D

import basicOperation as Bo


def originVsPCA(dimension, origin_data, recon_data, mean, rightEigenVector):
    """ 将PCA前后的数据进行可视化对比 """
    if dimension == 2:
        fig, ax = plt.subplots()
        ax.scatter(origin_data[0], origin_data[1], facecolor="green", label="Origin Data")
        ax.scatter(recon_data[0], recon_data[1], facecolor='r', label='PCA Data')
        x = [mean[0] - 3 * rightEigenVector[0], mean[0] + 3 * rightEigenVector[0]]
        y = [mean[1] - 3 * rightEigenVector[1], mean[1] + 3 * rightEigenVector[1]]
        ax.plot(x, y, color='blue', label='eigenVector direction', alpha=0.5)
        ax.set_title('origin_data And PCA_data', fontsize=16)
        ax.set_xlabel('$x$', fontdict={'size': 14, 'color': 'black'})
        ax.set_ylabel('$y$', fontdict={'size': 14, 'color': 'black'})
    elif dimension == 3:
        fig = plt.figure()
        ax = Axes3D(fig)
        ax.scatter(origin_data[0], origin_data[1], origin_data[2], facecolor='green', label='Origin Data')
        ax.scatter(recon_data[0], recon_data[1], recon_data[2], facecolor='r', label='PCA Data')
        # 画出2条eigen Vector 方向直线
        x = [mean[0] - 3 * rightEigenVector[0, 0], mean[0] + 3 * rightEigenVector[0, 0]]
        y = [mean[1] - 3 * rightEigenVector[1, 0], mean[1] + 3 * rightEigenVector[1, 0]]
        z = [mean[2] - 3 * rightEigenVector[2, 0], mean[2] + 3 * rightEigenVector[2, 0]]
        ax.plot(x, y, z, color='blue', label='eigenVector1 direction', alpha=1)
        x2 = [mean[0] - 3 * rightEigenVector[0, 1], mean[0] + 3 * rightEigenVector[0, 1]]
        y2 = [mean[1] - 3 * rightEigenVector[1, 1], mean[1] + 3 * rightEigenVector[1, 1]]
        z2 = [mean[2] - 3 * rightEigenVector[2, 1], mean[2] + 3 * rightEigenVector[2, 1]]
        ax.plot(x2, y2, z2, color='purple', label='eigenVector2 direction', alpha=1)

        ax.set_title('origin_data And PCA_data', fontsize=16)
        ax.set_zlabel('$z$', fontdict={'size': 14, 'color': 'red'})
        ax.set_ylabel('$y$', fontdict={'size': 14, 'color': 'red'})
        ax.set_xlabel('$x$', fontdict={'size': 14, 'color': 'red'})
    else:
        assert False

    plt.legend()
    plt.show()


def drawFace(recon_data, N, size):
    """
    画出降维重构之后的图像
    """
    plt.figure(figsize=size)
    for i in range(N):
        plt.subplot(2, 2, i + 1)
        plt.imshow(recon_data[:, i].reshape(size))
    plt.show()


def psnrChange(origin_data, dimRange):
    psnrList = []
    for dim in dimRange:
        c_data, rightEigenVector, mean, recon_data = Bo.PCA(origin_data, dim)
        a = Bo.psnr(origin_data[:, 1], recon_data[:, 1])
        psnrList.append(a)
    fig, ax = plt.subplots()
    ax.plot(dimRange, np.array(psnrList), color='r')
    ax.set_title('the PSNR change with different Target dimension', fontsize=18)
    ax.set_xlabel('$target dimension$', fontdict={'size': 14, 'color': 'black'})
    ax.set_ylabel('$psnr$', fontdict={'size': 14, 'color': 'black'})
    plt.show()
